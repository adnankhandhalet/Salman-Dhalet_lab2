
import java.util.Scanner;
class task6{
public static void main(String []args){
Scanner input =new Scanner(System.in);
System.out.println("Enter your age :");
int age =input.nextInt();
String result=(age>18)? "You are eligible for voting . " : " Sorry , You are not eligible for voting .";

System.out.println(result);

}

}