        			// Task 08:Salman Alias Adnan
	import java.util.Sacnner;
	public class task8{
	public static void main (String [] args){
	Scanner speed=newValue Scanner (System.in);
	
	System.out.println("Enter the ")
	double mile=speed.nextDouble();
	
}
}