		// Task 05:Salman Alias Adnan

	public class task5{
	public static void main (String [] args){
	System.out.println("************");
	System.out.println("*	   *");
	System.out.println("*	   *");
	System.out.println("*	   *");
	System.out.println("*	   *");
	System.out.println("************");
}
}
